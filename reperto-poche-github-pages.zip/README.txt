RÉPERTO’POCHE — PROTOTYPE INSTALLABLE

Ce dossier contient une première application web installable (PWA) pour iPhone, iPad et Mac.

Fonctions présentes :
- accueil coloré Réperto’Poche ;
- rubrique Médicaments ;
- recherche ;
- fiches détaillées ;
- ajout et modification de fiches ;
- sauvegarde locale sur l’appareil ;
- fonctionnement hors ligne une fois l’application ouverte et ajoutée depuis Safari.

INSTALLATION SUR IPHONE
1. Mettre ce dossier sur une adresse web sécurisée (HTTPS).
2. Ouvrir cette adresse avec Safari sur l’iPhone.
3. Appuyer sur Partager.
4. Choisir « Sur l’écran d’accueil ».
5. Valider « Ajouter ».

IMPORTANT
Les données créées dans ce prototype restent sur l’appareil. Il n’y a ni compte, ni synchronisation, ni transfert de données médicales vers un serveur.

Pour une application distribuée directement comme une app App Store, il faudra ensuite une étape de développement et de signature Apple.
